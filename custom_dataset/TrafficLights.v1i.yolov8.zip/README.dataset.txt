# TrafficLights > 2024-06-24 12:28am
https://universe.roboflow.com/md-yasin/trafficlights-owqog

Provided by a Roboflow user
License: MIT

